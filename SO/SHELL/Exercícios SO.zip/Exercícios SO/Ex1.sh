
v1=$1
sinal=$2
v2=$3

if [ $sinal == '+' ]; then
	let resut=$v1+$v2
	echo $resut
elif [ $sinal == '-' ]; then
	let resut=$v1-$v2
	echo $resut
elif [ $sinal == 'x' ]; then
	let resut=$v1*$v2
	echo $resut
elif [ $sinal == '/' ]; then
	let resut=$v1/$v2
	echo $resut
elif [ $sinal == '%' ]; then
	let resut=$v1%$v2
	echo $resut
fi
