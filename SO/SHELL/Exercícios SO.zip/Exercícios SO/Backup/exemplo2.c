#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]){
	FILE *origem;
	char str[255];
	char palavra[10];
	if(argc!=3){
		puts("Formato invalido");
		puts("Vre: my grep palavra origem");
		return 0;
	}
	else{
		//palavra=argv[1];
		origem=fopen(argv[2],"r");
		int oc=0;
		if(origem != NULL){
			while(fscanf(origem,"%s",str) != EOF){
				if(strstr(str,argv[1])){
					printf("'%s'\n",str);
					oc++;
				}
			}
			printf("A palavra '%s'",argv[1]);
			printf(" teve %i",oc);
			printf(" ocorrencia(s)\n");
		}
		else
			puts("Falha na operação com os arquivos\n");
		fclose(origem);
		return 0;
	}
}
