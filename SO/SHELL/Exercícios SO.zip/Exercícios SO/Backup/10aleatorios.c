#include <stdio.h> 
#include <stdlib.h>

int main()
{
	int n;
	printf("Digite  até que numero sera:");
	scanf("%d", & n);
	for(int i=0; i<10; i++){
		int x = rand() % n;
		printf("%d\n", x); 
		}
	return 0;
}
