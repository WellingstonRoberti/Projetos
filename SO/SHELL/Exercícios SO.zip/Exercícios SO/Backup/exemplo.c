#include <stdio.h>

int main(int argc, char* argv[]){
	FILE *origem, *destino;
	char str[255];
	if(argc!=3){
		puts("Formato invalido!");
		puts("Vre: my copy origem destino");
		return 0;
	}
	else{
		origem=fopen(argv[1],"r");
		destino=fopen(argv[2],"w");
		int ok=0;
		if(origem && destino){
			while(fscanf(origem,"%s",str) != EOF){
				fprintf(destino,"%s\n",str);
			}
			ok=1;
		}
		else
			puts("Falha na operação com os arquivos\n");
		fclose(origem);
		fclose(destino);
		return ok;
	}
}
