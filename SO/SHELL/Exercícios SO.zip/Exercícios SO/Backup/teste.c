#include <stdio.h>

int main(int argc, char * argv[]){
	FILE *origem, *destino; //arquivos
	char str[255]; // buffer
	origem=fopen(argv[1],"r"); //leitura
	destino=fopen(argv[2],"w"); //escrita
	while(fscanf(origem,"%s\n",str)!=EOF){
		fprintf(destino,"%s ",str);
	}
	fclose(origem);
	fclose(destino);
	//for(int i=0; i<argc; i++)
		//printf("%s \n",argv[i]);
	return 0;
}
