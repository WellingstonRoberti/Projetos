
if [ ! -d "backup" ]; then
	mkdir "backup"
	cp ~/* "backup"/
	
else
	echo "Já existe"
fi
