
nomePasta=$1
zip=$2
if [ ! -d $nomePasta ]; then
	mkdir $nomePasta
	cp ~/* $nomePasta/
	if [ $zip == 'zip' ]; then
		zip $nomePasta.zip $nomePasta/*
	else
		echo "Backup realizado"
	fi
	
else
	echo "Já existe"
fi
