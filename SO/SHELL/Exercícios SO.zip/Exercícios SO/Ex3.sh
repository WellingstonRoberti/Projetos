
nomePasta=$1

if [ ! -d $nomePasta ]; then
	mkdir $nomePasta
	cp ~/* $nomePasta/
	
else
	echo "Já existe"
fi
